import os
os.system("gnome-terminal -e 'bash -c \"sudo python ~/topo.py; exec bash\" ' ")
