#!/usr/bin/python
# -*- coding: utf-8 -*-

from tkinter import *
from tkinter.ttk import *
from PIL import ImageTk, Image
#import ImageTk

class Example(Frame):
  
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent
        
        self.initUI()


    def initUI(self):
      
        self.parent.title("EP3-SIMULATOR")
        
        self.parent.canvas=Canvas(width=10, height=40)
        self.parent.canvas.pack(expand=YES, fill=BOTH)
	
        self.columnconfigure(0, pad=10)
        self.columnconfigure(1, pad=10)
        self.columnconfigure(2, pad=10)
        
        self.rowconfigure(0, pad=10)
        self.rowconfigure(1, pad=10)
        self.rowconfigure(2, pad=20)	      
        def m1():
                exec(open("/home/i/kk/Run_topo.py").read())       
        c1 = Button(self, text=" Create Mininet Topology", command=m1)
        c1.grid(row=0, column=0, padx=10, pady=10, sticky=E+W+S+N)

        def m2():
                exec(open("/home/i/kk/Run_controller.py").read())
        c2 = Button(self, text=" Run Controller", command=m2)
        c2.grid(row=0, column=1,padx=10, pady=10, sticky=E+W+S+N)

        def m3():
                exec(open("/home/i/kk/UI.py").read())
        c3 = Button(self, text= "topoUI", command=m3)
        c3.grid(row=0, column=2,padx=10, pady=10, sticky=E+W+S+N)    
        
        def m6():
                import sys
                sys.exit()
        c6 = Button(self, text="Exit", command=m6)
        c6.grid(row=2, column=1, padx=30, pady=30, sticky=E+W+S+N) 
 
        self.pack()

def main():
  
    root = Tk()
    app = Example(root)
    root.mainloop()  


if __name__ == '__main__':
    main()  
