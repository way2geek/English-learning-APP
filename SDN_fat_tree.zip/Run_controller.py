import os 
os.system("gnome-terminal -e 'bash -c \"sudo java -jar ~/kk/target/floodlight.jar; exec bash\" ' ")

